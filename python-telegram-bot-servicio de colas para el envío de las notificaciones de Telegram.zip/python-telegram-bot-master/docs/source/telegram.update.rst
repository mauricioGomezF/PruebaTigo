Update
======

.. autoclass:: telegram.Update
    :members:
    :show-inheritance:
