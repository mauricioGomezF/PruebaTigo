VideoChatEnded
==============

.. autoclass:: telegram.VideoChatEnded
    :members:
    :show-inheritance:

