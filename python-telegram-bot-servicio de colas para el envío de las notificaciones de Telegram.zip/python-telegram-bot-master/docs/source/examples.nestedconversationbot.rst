``nestedconversationbot.py``
============================

.. literalinclude:: ../../examples/nestedconversationbot.py
   :language: python
   :linenos:

.. _nestedconversationbot-diagram:

State Diagram
-------------

.. mermaid:: ../../examples/nestedconversationbot.mmd
