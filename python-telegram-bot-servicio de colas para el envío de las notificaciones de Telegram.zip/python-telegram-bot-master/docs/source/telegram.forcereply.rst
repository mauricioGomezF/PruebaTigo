ForceReply
==========

.. autoclass:: telegram.ForceReply
    :members:
    :show-inheritance:
