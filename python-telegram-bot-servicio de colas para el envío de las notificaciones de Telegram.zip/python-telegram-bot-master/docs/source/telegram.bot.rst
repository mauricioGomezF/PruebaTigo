Bot
===

.. autoclass:: telegram.Bot
    :members:
    :show-inheritance:
    :special-members: __reduce__, __deepcopy__