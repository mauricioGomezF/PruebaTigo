InlineQueryResultDocument
=========================

.. autoclass:: telegram.InlineQueryResultDocument
    :members:
    :show-inheritance:
