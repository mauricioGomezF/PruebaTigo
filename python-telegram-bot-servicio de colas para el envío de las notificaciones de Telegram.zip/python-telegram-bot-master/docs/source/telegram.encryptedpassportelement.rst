EncryptedPassportElement
========================

.. autoclass:: telegram.EncryptedPassportElement
    :members:
    :show-inheritance:
