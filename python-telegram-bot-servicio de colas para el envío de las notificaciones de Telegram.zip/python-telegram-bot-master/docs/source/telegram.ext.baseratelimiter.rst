BaseRateLimiter
===============

.. autoclass:: telegram.ext.BaseRateLimiter
    :members:
    :show-inheritance:
