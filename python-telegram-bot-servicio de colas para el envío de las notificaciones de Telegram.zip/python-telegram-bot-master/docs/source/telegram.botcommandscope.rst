BotCommandScope
===============

.. autoclass:: telegram.BotCommandScope
    :members:
    :show-inheritance: