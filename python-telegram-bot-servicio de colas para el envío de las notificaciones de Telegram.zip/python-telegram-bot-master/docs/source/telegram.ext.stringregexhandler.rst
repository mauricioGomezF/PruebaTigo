StringRegexHandler
==================

.. autoclass:: telegram.ext.StringRegexHandler
    :members:
    :show-inheritance:
