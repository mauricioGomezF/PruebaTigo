MaskPosition
============

.. autoclass:: telegram.MaskPosition
    :members:
    :show-inheritance:
