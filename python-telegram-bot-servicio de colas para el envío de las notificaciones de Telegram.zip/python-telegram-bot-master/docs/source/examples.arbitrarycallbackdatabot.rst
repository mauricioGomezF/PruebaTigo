``arbitrarycallbackdatabot.py``
===============================

.. literalinclude:: ../../examples/arbitrarycallbackdatabot.py
   :language: python
   :linenos:
    