Read the tutorial:

* On FreeCodeCamp: https://www.freecodecamp.org/news/how-to-create-a-telegram-bot-using-python/
* On Hashnode: https://ashutoshkrris.hashnode.dev/how-to-create-a-telegram-bot-using-python